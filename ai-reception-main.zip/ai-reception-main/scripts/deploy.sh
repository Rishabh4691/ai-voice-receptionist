#!/usr/bin/env bash
# Manual deploy helper. Usage: ./scripts/deploy.sh [dev|staging|prod]
# Mirrors exactly what GitHub Actions does, useful for emergency rollbacks
# or deploying without a git push.

set -euo pipefail

ENV="${1:-dev}"
APP_DIR="/home/kanal/apps/voice-bot-api"

case "$ENV" in
  dev)
    BRANCH="main"
    COMPOSE_FILE="docker-compose.dev.yml"
    PORT="3040"
    ;;
  staging)
    BRANCH="staging"
    COMPOSE_FILE="docker-compose.staging.yml"
    PORT="3041"
    ;;
  prod)
    BRANCH="prod"
    COMPOSE_FILE="docker-compose.prod.yml"
    PORT="3042"
    ;;
  *)
    echo "Usage: $0 [dev|staging|prod]"
    exit 1
    ;;
esac

echo "==> Deploying env: $ENV (branch: $BRANCH, port: $PORT)"

cd "$APP_DIR"
git fetch origin
git checkout "$BRANCH"
git reset --hard "origin/$BRANCH"

docker compose -f "$COMPOSE_FILE" up --build -d
docker image prune -f

sleep 5
curl -sf "http://127.0.0.1:${PORT}/api/health" && echo "✓ Health check passed for $ENV"
echo "==> Deploy complete: $ENV"
